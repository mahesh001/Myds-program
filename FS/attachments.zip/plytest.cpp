#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<string>
using namespace std;
struct part
{
	int p;
	int s;
};
void getvalues(int x[])
{
	x[0]=7;
	x[1]=6;
	x[2]=4;
}
void clear(int v[],int k)
{
	for(int i=0;i<k;i++)
	v[i]=0;
}
int av(int v[],int k)
{
	int r=1;
	for(int i=0;i<k;i++)
	{
		if(v[i]==0)
		r=0;
	}
	return(r);
}
void initialise(part pr[],int k,int size)
{
	for(int i=0;i<=k;i++)
	{
		if(i==k)
		{
			pr[i].p=0;
			pr[i].s=0;
		}
		else
		{
			pr[i].p=0;
			pr[i].s=size;
		}
	}
}
void print(part pr[],int k)
{
	for(int i=0;i<=k;i++)
	{
		cout<<pr[i].p<<"\t"<<pr[i].s<<"\n";
	}
}
int sizefull(part pr[],int k,int n)
{
	int r=0;
	for(int i=0;i<=k;i++)
	{
		if(pr[i].s==n)
		r=1;
	}
	return(r);
}
int findmin(part pr[],int k,int of)
{
	int min=1000,index=-1;
	for(int i=0;i<=k;i++)
	{
		if(i!=of)
		{
			if(min>pr[i].p)
			{
				min=pr[i].p;
				index=i;
			}
		}
	}
	return(index);
}
int main()
{
	int count;
	char buffer[100];
	fstream fin;
	int q,n,c,i,size,j,k,m,np;
	cout<<"enter no. of partions\n";
	cin>>np;
	cout<<"enter size of partitions\n";
	cin>>size;
	cout<<"enter order of sort\n";
	cin>>k;
	n=np*size;
	fstream f[k+1];
	int a[size];
	part pr[k+1];
	initialise(pr,k,size);
	string s1;
	s1="a";
	for(i=0;i<=k;i++)
	{
		f[i].open((s1+".txt").c_str(),ios::out);
		s1=s1+"a";
	}
	fin.open("datafile2.txt",ios::in);
	int x[k];
	getvalues(x);
	for(i=0;i<k;i++)
	cout<<x[i]<<",";
	cout<<"\n";
	int v[k];
	clear(v,k);
	int d=-1;
	while(!av(v,k))
	{
		for(i=0;i<size;i++)
		{
			fin.getline(buffer,6,'\n');
			if(atoi(buffer)!=0)
			a[i]=atoi(buffer);
			else
			break;
		}
		c=size;
		sort(a,a+c);
		for(i=0;i<size;i++)
		cout<<a[i]<<",";
		cout<<"\n";
		q=(++d)%k;
		cout<<"q is "<<q<<"\n";
		while(v[q]!=0)
		q--;
		if(q>=0)
		{
			for(i=0;i<c;i++)
			f[q]<<a[i]<<"\n";
			pr[q].p++;
			if(pr[q].p==x[q])
			v[q]=1;
		}
	}
	for(i=0;i<=k;i++)
	f[i].close();
	print(pr,k);
	int minf,of;
	of=k;
	minf=findmin(pr,k,of);
	cout<<"min is "<<minf<<"\n";
	while(!sizefull(pr,k,n))
	{
		s1="a";
		for(i=0;i<=k;i++)
		{
			if(i==of)
			f[i].open((s1+".txt").c_str(),ios::out);
			else
			f[i].open((s1+".txt").c_str(),ios::in);
			
		}
		
	}
}
