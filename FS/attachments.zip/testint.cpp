#include<iostream>
using namespace std;
int main()
{
	int a=100000;
	cout<<a;
	
}
