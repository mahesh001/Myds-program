#include<iostream>
#include<fstream>
#include<cstdlib>
using namespace std;
int main()
{
	fstream f;
	char buffer[100];
	f.open("i.txt",ios::in);
	f.getline(buffer,10,'\n');
	cout<<buffer;
	int i=atoi(buffer);
	cout<<i;
}
