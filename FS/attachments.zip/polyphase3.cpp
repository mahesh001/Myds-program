#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<string>
using namespace std;
struct part
{
	int p;
	int s;
};
void getvalues(int x[])
{
	x[0]=7;
	x[1]=6;
	x[2]=4;
}
void clear(int v[],int k)
{
	for(int i=0;i<k;i++)
	v[i]=0;
}
void clears(int v[],int k)
{
	for(int i=0;i<=k;i++)
	v[i]=0;
}
int av(int v[],int k)
{
	int r=1;
	for(int i=0;i<k;i++)
	{
		if(v[i]==0)
		r=0;
	}
	return(r);
}
int avs(int v[],int k)
{
	int r=1;
	for(int i=0;i<=k;i++)
	{
		if(v[i]==0)
		r=0;
	}
	return(r);
}
void initialise(part pr[],int k,int size)
{
	for(int i=0;i<=k;i++)
	{
		if(i==k)
		{
			pr[i].p=0;
			pr[i].s=0;
		}
		else
		{
			pr[i].p=0;
			pr[i].s=size;
		}
	}
}
void print(part pr[],int k)
{
	for(int i=0;i<=k;i++)
	{
		cout<<pr[i].p<<"\t"<<pr[i].s<<"\n";
	}
}
int sizefull(part pr[],int k,int n)
{
	int r=0;
	for(int i=0;i<=k;i++)
	{
		if(pr[i].s==n)
		r=1;
	}
	return(r);
}
int findmin(part pr[],int k,int of)
{
	int min=1000,index=-1;
	for(int i=0;i<=k;i++)
	{
		if(i!=of)
		{
			if(min>pr[i].p)
			{
				min=pr[i].p;
				index=i;
			}
		}
	}
	return(index);
}
int findminimum(int a[],int t)
{
	int min=100000,index=-1;
	for(int i=0;i<=t;i++)
	{
		if(min>a[i])
		{
			min=a[i];
			index=i;
		}
	}
	if(min==10000)
	return(10000);
	else
	return(index);
}
void print(int b[],int k)
{
	for(int i=0;i<=k;i++)
	cout<<b[i]<<",";
	cout<<"\n";
}
int main()
{
	int count;
	char buffer[100];
	fstream fin;
	int q,n,c,i,size,j,k,l,m,np,temp,mf;
	cout<<"enter no. of partions\n";
	cin>>np;
	cout<<"enter size of partitions\n";
	cin>>size;
	cout<<"enter order of sort\n";
	cin>>k;
	n=np*size;
	cout<<"n is "<<n<<"\n";
	fstream f[k+1];
	int a[size];
	part pr[k+1];
	initialise(pr,k,size);
	string s1;
	s1="a";
	for(i=0;i<=k;i++)
	{
		f[i].open((s1+".txt").c_str(),ios::out);
		s1=s1+"a";
	}
	fin.open("datafile2.txt",ios::in);
	int x[k],b[k+1],V[k+1],C[k+1];
	getvalues(x);
//	for(i=0;i<k;i++)
//	cout<<x[i]<<",";
//	cout<<"\n";
	int v[k];
	clear(v,k);
	int d=-1;
	while(!av(v,k))
	{
//		cout<<"entered into first loop\n";
//		cout<<"enter 1 to continue \n";
//		cin>>count;
		for(i=0;i<size;i++)
		{
			fin.getline(buffer,6,'\n');
			if(atoi(buffer)!=0)
			a[i]=atoi(buffer);
			else
			break;
		}
		c=size;
//		cout<<"now c is "<<c<<"\n";
		sort(a,a+c);
//		for(i=0;i<size;i++)
//		cout<<a[i]<<",";
//		cout<<"\n";
//		cin>>count;
//		cout<<"sorted\n";
//		cin>>count;
		q=(++d)%k;
//		cout<<"q is "<<q<<"\n";
		while(v[q]!=0)
		{
			q--;
		}
//		cout<<"now q is "<<q<<"\n";
		if(q>=0)
		{
//			cout<<"came here\n";
//			cout<<"before loop c is"<<c<<"\n";
			for(i=0;i<c;i++)
			{
//				cout<<"here c is "<<c<<"\n";
				f[q]<<a[i]<<"\n";
			}
			pr[q].p++;
//			cout<<pr[q].p<<"is the p value\n";
//			cin>>count;
			if(pr[q].p==x[q])
			{
				v[q]=1;
//				cout<<"visited "<<q<<"\n";
//				cin>>count;
			}
		}
	}
	for(i=0;i<=k;i++)
	{
		f[i].close();
		cout<<"close\n";
	}
	print(pr,k);
	int minf,of;
	of=k;
	minf=findmin(pr,k,of);
	cout<<"min is "<<minf<<"\n";
	cout<<"of is "<<of<<"\n";
	temp=0;
	cin>>l;
	mf=-1;
	while(!sizefull(pr,k,n))
	{
		s1="a";
		for(i=0;i<=k;i++)
		{
			if(i==of)
			f[i].open((s1+".txt").c_str(),ios::out);
			else
			f[i].open((s1+".txt").c_str(),ios::in);
			s1=s1+"a";
		}
		for(i=0;i<=k;i++)
		{
			if(i!=of)
			{
				f[i].seekg(temp*pr[i].s,ios::beg);
			}
			if(mf!=-1&&i==mf)
			f[i].seekg(0,ios::beg);
			cout<<i<<"th file tellg is "<<f[i].tellg()<<"\n";
		}
		cin>>l;
		cout<<"entetred here\n";
		cout<<pr[minf].p<<"\n";
		for(j=0;j<pr[minf].p;j++)
		{
			cout<<j<<"th iteration\n";
			clears(V,k);
			V[of]=1;
			cout<<"array v is \n";
			print(V,k);
			clears(C,k);
			cout<<"array  C is\n";
			print(C,k);
			for(i=0;i<=k;i++)
			{
//				cout<<"entered here 2\n";
				if(i==of)
				b[i]=10000;
				else
				{
					f[i].getline(buffer,6,'\n');
					b[i]=atoi(buffer);
					C[i]++;
				}	
			}
			cout<<"array b is \n";
			print(b,k);
			m=findminimum(b,k);
			while(m!=10000)
			{
				cout<<"entered here 3\n";
//				cin>>l;
//				if(m!=10000)
//				{
//					cout<<"entered here 4\n";
					cout<<"m is "<<m<<"\n";
					cout<<"b[m]= "<<b[m]<<"\n";
					f[of]<<b[m]<<"\n";
					if(V[m]==0)
					{
						f[m].getline(buffer,6,'\n');
						if(!f[m].eof())
						{
							b[m]=atoi(buffer);
							C[m]++;
							cout<<pr[m].s<<"\n";
							if(C[m]==pr[m].s)
							{
								cout<<"came here 5\n";
								V[m]=1;
							}
						}
						else
						{
							b[m]=10000;
							V[m]=1;
						}
					}
					else
					b[m]=10000;
					cout<<"b array is \n";
					print(b,k);
					m=findminimum(b,k);
//				}
				cout<<"array  C is \n";
				print(C,k);
				cout<<"array V is \n";
				print(V,k);
//				cin>>l;
			}
		}
		for(i=0;i<=k;i++)
		f[i].close();
		temp=pr[minf].p;
		pr[of].p=pr[minf].p;
		for(i=0;i<=k;i++)
		{
			if(i!=of)
			pr[of].s=pr[of].s+pr[i].s;
//			cout<<pr[i].s<<",";
		}
//		cout<<"\n";
//		cout<<"of is "<<of<<"\n";
//		cout<<"s of of is "<<pr[of].s<<"\n";
//		cin>>l;
		for(i=0;i<=k;i++)
		{
			if(i!=of)
			{
				if(i!=minf)
				pr[i].p-=pr[minf].p;
			}
			cout<<i<<"th file p is "<<pr[i].p<<"\n";
		}
		cin>>l;
		mf=of;
		of=minf;
		cout<<"minf is "<<minf<<"\n";
		pr[minf].p=0;
		pr[minf].s=0;
		print(pr,k);
		cin>>l;
		minf=findmin(pr,k,of);
		cout<<"now of is "<<of<<"\n";
		cout<<"now minf is "<<minf<<"\n";
		cin>>l;
	}
}
