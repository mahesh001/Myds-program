#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
using namespace std;
int main()
{
	fstream fin;
	fin.open("datafile.txt",ios::in);
	cout<<"enter the partition size";
	cin>>s;
	cout<<"enter the value of k:";
	cin>>k;
	fstream f[2][k];
	string s1,s2;
	s1="a";
	s2="b";
	for(i=0;i<k;i++)
	{
		
	}
}
