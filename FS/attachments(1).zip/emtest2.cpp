#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cmath>
using namespace std;
int findmin(int a[],int t)
{
	int min=10000,index=-1;
	for(int i=0;i<t;i++)
	{
		if(min>a[i])
		{
			min=a[i];
			index=i;
		}
	}
	if(min==1000)
	return(1000);
	else
	return(index);
}
int main()
{
	int count;
	char buffer[100];
	fstream fin;
	fin.open("datafile.txt",ios::in);
	while(!fin.eof())
	{
		fin.getline(buffer,10,'\n');
		if(fin.eof())
		break;
		count++;
	}
	fin.close();
	cout<<count<<"\n";
	int i,k,j,c,s,n,m;
	n=count;
	cout<<"enter size of array\n";
	cin>>s;
	cout<<"enter order of sort\n";
	cin>>k;
	int a[s],p;
	int o[k],C[k];
	fstream f[2][k];
	string s1,s2;
	s1="a";
	s2="b";
	for(i=0;i<k;i++)
	{
		f[0][i].open((s1+".txt").c_str(),ios::out);
		f[1][i].open((s2+".txt").c_str(),ios::out);
		s1=s1+"a";
		s2=s2+"b";
		C[i]=0;
	}
	fin.open("datafile.txt",ios::in);
	count=0;
	c=n%s;
	m=(n-c)/s;
	while(count<m)
	{
		for(j=0;j<s;j++)
		{
			fin.getline(buffer,10,'\n');
			a[j]=atoi(buffer);
		}
		sort(a,a+s);
		p=count%k;
		for(j=0;j<s;j++)
		{
			f[0][p]<<a[j];
			f[0][p]<<"\n";
		}
		count++;
	}
	for(j=0;j<c;j++)
	{
		fin.getline(buffer,10,'\n');
		a[j]=atoi(buffer);
	}
	sort(a,a+c);
	p=count%s;
	for(j=0;j<c;j++)
	{
		f[0][p]<<a[j];
		f[0][p]<<"\n";
	}
	for(j=0;j<2;j++)
	for(i=0;i<k;i++)
	f[j][i].close();
	int tag=0;
	while(n>s)
	{
		if((++tag)%2==1)
		{
			string s1,s2;
			s1="a";
			s2="b";
			for(i=0;i<k;i++)
			{
				f[0][i].open((s1+".txt").c_str(),ios::in);
				f[1][i].open((s2+".txt").c_str(),ios::out);
				s1=s1+"a";
				s2=s2+"b";
			}
		}
		else
		{
			string s1,s2;
			s1="a";
			s2="b";
			for(i=0;i<k;i++)
			{
				f[0][i].open((s2+".txt").c_str(),ios::in);
				f[1][i].open((s1+".txt").c_str(),ios::out);
				s1=s1+"a";
				s2=s2+"b";
			}
		}
		p=-1;
		for(j=0;j<k;j++)
		{
			f[0][j].getline(buffer,10,'\n');
			o[j]=atoi(buffer);
		}
		for(j=0;j<k;j++)
		cout<<o[j]<<",";
		cout<<"\n";
		j=findmin(o,k);
		while(j!=1000)
		{
			
			cout<<"j ="<<j<<"\n";
			cout<<"o[j] ="<<o[j]<<"\n";
			if(o[j]!=0)
			{
				i=(++p)/(s*k);
				i=i%k;
				cout<<"p ="<<p<<"\n";
				cout<<"i ="<<i<<"\n";
				f[1][i]<<o[j]<<"\n";
				cout<<"here\n";
			}
			if(C[j]<=s)
			{
				cout<<"where\n";
				f[0][j].getline(buffer,10,'\n');
				if(f[0][j].eof())
				{
					o[j]=0;
				}else
				{
					o[j]=atoi(buffer);
					C[j]++;
				}
			}
			else
			{
				buffer[0]=0;
			}
			o[j]=atoi(buffer);
			if(o[j]==0)
			o[j]=1000;
			cout<<"next element in to array "<<o[j]<<"\n";
			j=findmin(o,k);
		}
		for(j=0;j<2;j++)
		for(i=0;i<k;i++)
		f[j][i].close();
		s=s*k;
		cout<<"s value is "<<s<<"\n";
		cout<<"enter a value\n";
		cin>>i;
		if(i==1)
		break;
	}
}
