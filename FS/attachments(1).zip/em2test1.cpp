#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cmath>
using namespace std;
int findmin(int a[],int t)
{
	int min=10000,index=-1;
	for(int i=0;i<t;i++)
	{
		if(min>a[i])
		{
			min=a[i];
			index=i;
		}
	}
	if(min==1000)
	return(1000);
	else
	return(index);
}
int main()
{
	int count;
	char buffer[100];
	fstream fin;
	fin.open("datafile.txt",ios::in);
	while(!fin.eof())
	{
		if(fin.eof())
		break;
		fin.getline(buffer,10,'\n');
		count++;
	}
	fin.close();
	count--;
	cout<<count<<"\n";
	int i,k,j,c,s,n,m;
	n=count;
	cout<<"enter size of array\n";
	cin>>s;
	cout<<"enter order of sort\n";
	cin>>k;
	int a[s],p;
	int o[k];
	fstream f[2][k];
	string s1,s2;
	s1="a";
	s2="b";
	for(i=0;i<k;i++)
	{
		f[0][i].open((s1+".txt").c_str(),ios::out);
		f[1][i].open((s2+".txt").c_str(),ios::out);
		s1=s1+"a";
		s2=s2+"b";
	}
	fin.open("datafile.txt",ios::in);
	count=0;
	c=n%s;
	m=(n-c)/s;
	while(count<m)
	{
		for(j=0;j<s;j++)
		{
			fin.getline(buffer,10,'\n');
			a[j]=atoi(buffer);
		}
		sort(a,a+s);
		p=count%k;
		for(j=0;j<s;j++)
		{
			f[0][p]<<a[j];
			f[0][p]<<"\n";
		}
		count++;
	}
	for(j=0;j<c;j++)
	{
		fin.getline(buffer,10,'\n');
		a[j]=atoi(buffer);
	}
	sort(a,a+c);
	p=count%s;
	for(j=0;j<c;j++)
	{
		f[0][p]<<a[j];
		f[0][p]<<"\n";
	}
	for(j=0;j<2;j++)
	for(i=0;i<k;i++)
	f[j][i].close();
	int tag=0;
	while(n>s)
	{
		if((++tag)%2==1)
		{
			string s1,s2;
			s1="a";
			s2="b";
			for(i=0;i<k;i++)
			{
				f[0][i].open((s1+".txt").c_str(),ios::in);
				f[1][i].open((s2+".txt").c_str(),ios::out);
				s1=s1+"a";
				s2=s2+"b";
			}
		}
		else
		{
			string s1,s2;
			s1="a";
			s2="b";
			for(i=0;i<k;i++)
			{
				f[0][i].open((s2+".txt").c_str(),ios::in);
				f[1][i].open((s1+".txt").c_str(),ios::out);
				s1=s1+"a";
				s2=s2+"b";
			}
		}
		i=-1;
		p=-1;
		for(j=0;j<k;j++)
		{
			f[0][j].getline(buffer,10,'\n');
			o[j]=atoi(buffer);
		}
		j=findmin(a,k);
		while(j!=1000)
		{
//			cout<<j<<"\n";
			j=findmin(o,k);
//			if(j!=1000)
//			{
				if(j==1000)
				{
					cout<<"breaking here \n";
					break;
				}
				cout<<"j ="<<j<<"\n";
				cout<<"o[j] ="<<o[j]<<"\n";
				if(o[j]!=0)
				{
					i=(++p)%k;
					cout<<"p ="<<p<<"\n";
					cout<<"i ="<<i<<"\n";
					f[1][i]<<o[j]<<"\n";
					cout<<"here\n";
				}
				if(!f[0][j].eof())
				{
					cout<<"where\n";
					f[0][j].getline(buffer,10,'\n');
				}
				else
				{
//					cout<<"breaking\n";
//					break;
					buffer[0]=0;
				}
				o[j]=atoi(buffer);
				if(o[j]==0)
				o[j]=1000;
				cout<<"next element in to array "<<o[j]<<"\n";
//			}
		}
		for(j=0;j<2;j++)
		for(i=0;i<k;i++)
		f[j][i].close();
		s=s*k;
		cout<<"s value is "<<s<<"\n";
	}
}
