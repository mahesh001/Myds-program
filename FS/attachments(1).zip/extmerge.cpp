#include<iostream>
#include<fstream>
#include<cstring>
#include<cstdlib>
using namespace std;
int main()
{
	int n,s,k,i,j,m;
	cout<<"enter no. of numbers to sorted \n";
	cin>>n;
	cout<<"enter size of array to be used \n";
	cin>>s;
	cout<<"enter k in kway merge sort\n";
	cin>>k;
	
}
