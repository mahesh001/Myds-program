#include<iostream>
#include<fstream>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
void write(fstream &f,int a[],int size)
{
	for(int i=0;i<size;i++)
			f<<a[i]<<endl;
}
int all_visited(int visited[],int size,int k)
{
	for(int j=0;j<size;j++)
		if(visited[j]<k)
		{
			return 0;
		}
	return 1;
}
int get_min(int b[],int visited[],int size,int k)
{
	int j,min=0;
	for(j=0;j<size;j++)
	{
		if(visited[min]==k&&visited[j]!=k)
			min=j;
		else if(b[min]>b[j]&&visited[j]!=k)
			min=j;
	}
	return min;
}
void clear_data(fstream &f)
{
	for(int i=0;i<10000;i++)
		f<<"";
}
int main()
{
	int k,s,i,tag,count,q,l,m,n,j,min,c;
	string s1,s2;
	cout<<"enter the value of k:";
	cin>>k;
	cout<<"enter the partition size:";
	cin>>s;
	int a[s],visited[k],b[k];
	ifstream fin;
	fstream f[2][k];
	fin.open("datafile.txt",ios::in);
	s1="a";
	s2="b";
	for(i=0;i<k;i++)
		{
			visited[i]=0;
			f[0][i].open((s1+".txt").c_str(),ios::in | ios::out | ios::trunc);
			f[1][i].open((s2+".txt").c_str(),ios::in | ios::out | ios::trunc);
			s1=s1+"a";
			s2=s2+"b";
		}
	tag=count=0;
	while(!fin.eof())
	{
		for(i=0;i<s&&!fin.eof();i++)
		{
			fin>>a[i];
			if(fin.eof())
				break;
			count++;
		}
		sort(a,a+i);
		write(f[0][tag],a,i);
		tag=(tag+1)%k;
	}
	q=s;
	l=0;
	c=s;
	while(l<=0)
	{
		if(l%2==0)
		{
			m=0;n=1;
		}
		else
		{
			m=1;n=0;
		}
		for(i=0;i<k;i++)
		{	
			cout<<f[m][i].tellg()<<" ";
			f[m][i].seekg(0,ios::beg);
		}
		for(i=0;i<k;i++)
		{
			f[n][i].close();
		}
		if(n==0)
		{
			s1="a";
			for(i=0;i<k;i++)
			{
				f[0][i].open((s1+".txt").c_str(),ios::in | ios::out | ios::trunc);
				s1=s1+"a";
			}
		}
		else 
		{
			s1="b";
			for(i=0;i<k;i++)
			{
				f[1][i].open((s1+".txt").c_str(),ios::in | ios::out | ios::trunc);
				s1=s1+"b";
			}
		}
		tag=0;
		cout<<"m is "<<m;
		while(!f[m][0].eof())
		{
			for(i=0;i<k;i++)
			{
				f[m][i]>>b[i];
				cout<<m<<i;
				visited[i]=1;
				if(f[m][i].eof())
					break;
			}
			while(!all_visited(visited,i,c+1))
			{
				min=get_min(b,visited,i,c+1);
				cout<<b[min]<<" "<<tag<<" "<<n<<endl;
				f[n][tag]<<b[min]<<endl;
				if(!f[m][min].eof()&&visited[min]!=c)
				{
					f[m][min]>>b[min];
					visited[min]++;
				}
				else if(visited[min]==c)
				{	
					visited[min]++;
				}
				 if(f[m][min].eof())
				{
					visited[min]=c+1;
				}
			}
			tag=(tag+1)%k;
		}
		q=q*k;
		c=c*k;
		l++;
		cout<<q;
	}
}
